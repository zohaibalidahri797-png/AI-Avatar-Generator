# AvatarForge — Deployment Guide

AvatarForge is a **full-stack Next.js 16 (App Router) application**: a marketing +
SEO frontend **and** a real server-side AI endpoint (`POST /api/generate-avatar`).
It is **not** a static website and must never be deployed as one — a static
export cannot run the AI route.

## Deployment architecture (verified)

**Next.js 16 + Cloudflare Workers via [vinext](https://www.npmjs.com/package/vinext)**
(Cloudflare's recommended path for Next.js on Workers) with `nodejs_compat`.

```
bun run build:vinext   → vinext build   (dist/client + dist/server)
bun run start:vinext   → wrangler dev   (local Workers runtime preview on :8787)
bun run deploy:vinext  → vinext-cloudflare deploy
```

The vinext build aliases `z-ai-web-dev-sdk` to `src/lib/zai-workers.ts`, a
fetch-based client that reads credentials from **Worker secrets** (the real SDK
reads a config file from disk, which is impossible in Workers). The frontend API
contract is identical in both runtimes.

The standard Next.js workflow still works everywhere else (Node hosts, VPS,
Docker):

```
bun install
bun run dev        # development (:3000)
bun run build      # next build
bun run start      # next start
```

## Before you deploy — one-time checklist

1. **KV namespace** (vinext cache):
   ```bash
   npx wrangler kv namespace create VINEXT_KV_CACHE
   ```
   Put the returned `id` into `wrangler.jsonc` (replace the all-zero placeholder).

2. **Secrets** (server-side only — never committed, never client-visible):
   ```bash
   npx wrangler secret put ZAI_API_KEY
   npx wrangler secret put ZAI_BASE_URL
   # optional — only if your AI provider requires the extra auth headers:
   npx wrangler secret put ZAI_TOKEN
   npx wrangler secret put ZAI_CHAT_ID
   npx wrangler secret put ZAI_USER_ID
   ```
   Local preview: copy `.dev.vars.example` to `.dev.vars` (gitignored) and fill
   in the same values. `wrangler dev` loads them automatically.

3. **Public build-time variables** (baked into the bundle — set them in the
   environment when running the build, exactly like `NEXT_PUBLIC_*` in Next.js):
   - `NEXT_PUBLIC_SITE_URL` — canonical production origin, e.g. `https://yourdomain.com`
     (no trailing slash). Drives canonical tags, OG/Twitter URLs, sitemap.xml,
     robots.txt, feed.xml and all JSON-LD. **Never ship a build without it.**
   - `NEXT_PUBLIC_SUPPORT_EMAIL` — optional. When unset, the site honestly says
     "use the contact page" instead of inventing an address.

   ```bash
   NEXT_PUBLIC_SITE_URL=https://yourdomain.com \
   NEXT_PUBLIC_SUPPORT_EMAIL=support@yourdomain.com \
   bun run build:vinext
   bun run deploy:vinext
   ```

## Environment variable reference

| Variable                  | Scope            | When it is read     | Secret? |
| ------------------------- | ---------------- | ------------------- | ------- |
| `ZAI_API_KEY`             | server only      | runtime (per request) | **SECRET** |
| `ZAI_BASE_URL`            | server only      | runtime (per request) | **SECRET** |
| `ZAI_TOKEN` / `ZAI_CHAT_ID` / `ZAI_USER_ID` | server only | runtime | **SECRET** (optional) |
| `NEXT_PUBLIC_SITE_URL`    | build-time       | build               | public  |
| `NEXT_PUBLIC_SUPPORT_EMAIL` | build-time     | build               | public  |

Secrets are never referenced in client components and are never inlined into
the client bundle. `NEXT_PUBLIC_*` variables are, by definition, public.

## Which script does what

| Script             | Purpose                                          |
| ------------------ | ------------------------------------------------ |
| `dev`              | Next.js dev server (:3000)                       |
| `build` / `start`  | Next.js production build / Node server           |
| `dev:vinext`       | vinext dev server (:3001)                        |
| `build:vinext`     | Workers build (`dist/client` + `dist/server`)    |
| `start:vinext`     | Local Workers preview via `wrangler dev` (:8787) |
| `deploy:vinext`    | Deploy to Cloudflare Workers                     |
| `lint` / `typecheck` | ESLint / `tsc --noEmit` (0 errors required)    |

## Verified in this repository (2026-09-12)

- `next build` from a clean `.next`: **passes, 61 pages/routes, 0 TS errors**
- `vinext build`: **passes** (all 32 routes + 3 route handlers)
- Workers runtime preview (`wrangler dev`, workerd): all 31 public routes 200,
  real 404 for unknown URLs, sitemap.xml (53 URLs) / robots.txt / feed.xml OK,
  no hash URLs / no localhost / no placeholder domains in served HTML
- Real AI generation on the Workers runtime: **HTTP 200, ~15 s, valid 1024×1024
  image** via the env-secret fetch client; invalid upload → 400, oversized → 413
  with the exact safe error copy
- AI generation on the Node path (`next dev` / `next start`): **HTTP 200, ~16 s**
  via the SDK config-file client

## Must-verify-on-your-account (cannot be done from this sandbox)

- `npx wrangler kv namespace create` + paste the real id (step 1 above)
- `wrangler secret put …` with your real provider credentials
- One real generation against the deployed `*.workers.dev` URL before DNS cutover
- Rate limiting (optional): if you want per-IP limits on `/api/generate-avatar`,
  add a KV/Durable-Object–based limiter in the route or a Cloudflare WAF rule —
  client-side limiting alone is not trustworthy

## Deployment anti-patterns (do not do)

- Do **not** upload the repo as a static site / use `output: "export"` — the AI
  endpoint is server-side and would be missing.
- Do **not** commit `.dev.vars`, `.z-ai-config`, or any real credentials.
- Do **not** deploy a build made without `NEXT_PUBLIC_SITE_URL` — SEO files and
  metadata would fall back to `http://localhost:3000` (dev-only fallback).
- Do **not** mix Next.js standalone output with Workers/Pages static deploys —
  standalone output has been removed from this project on purpose.
