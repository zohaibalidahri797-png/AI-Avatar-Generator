# AvatarForge — Deployment Guide

## Architecture (chosen)

**Option B — a properly configured Next.js (App Router) deployment with a server runtime.**

The site is a standard Next.js 16 App Router application. Every public page is a
server-rendered, crawlable route under `src/app/`, and the AI generation endpoint
(`src/app/api/generate-avatar/route.ts`) runs **server-side only**: the AI provider
credentials never reach client JavaScript.

`next.config.ts` uses `output: "standalone"`, `trailingSlash: true`.

## Required environment variables

| Variable                    | Required | Description                                                        |
| --------------------------- | -------- | ------------------------------------------------------------------ |
| `NEXT_PUBLIC_SITE_URL`      | Yes      | Canonical origin, e.g. `https://avatarforge.com` (no trailing slash). Used by canonical URLs, OG/Twitter tags, JSON-LD, sitemap.xml, robots.txt and the RSS feed. Falls back to `http://localhost:3000` in development only. |
| `NEXT_PUBLIC_SUPPORT_EMAIL` | No       | Support address shown on the contact/about/legal pages. When unset, the UI honestly falls back to "use the contact page" copy — no placeholder email is ever rendered. |

## Verified target (Node.js server / Vercel-style)

Works out of the box:

```bash
bun install
NEXT_PUBLIC_SITE_URL=https://your-domain.com bun run build
bun run start   # serves the standalone build
```

Verified in this environment: all routes respond directly (200), unknown URLs
return 404, `/sitemap.xml`, `/robots.txt` and `/feed.xml` render with the
configured domain, and `POST /api/generate-avatar` performs real AI
generation (200, ~15 s).

## Cloudflare deployment

Two supported paths — pick one before going live:

1. **Option B (recommended, least change):** deploy via the official
   [`@opennextjs/cloudflare`](https://opennext.js.org/cloudflare) adapter, which
   runs the Next.js server (including the API route) on Cloudflare Workers.
   The API route uses no Node-only APIs beyond the SDK (SDK network calls go
   over HTTPS), so it is adapter-compatible, but **you must run the adapter's
   preview (`opennextjs-cloudflare preview`) and test a real generation
   against the Worker runtime before switching DNS** — this sandbox cannot
   exercise the Workers runtime.

2. **Option A (static + serverless):** keep the frontend static and move
   `src/app/api/generate-avatar/route.ts` into a Cloudflare Worker/Pages
   Function that calls the AI provider. The route is deliberately thin
   (validate → build prompt → call provider → return JSON), so porting it is
   mechanical. Keep the exact error responses:
   - invalid image → `Please upload a JPG, PNG, or WebP image.`
   - too large → `That image is too large. Please choose a smaller image.`
   - failure → `Something went wrong while creating your avatar. Please try again.`

## Post-deploy checklist

- [ ] `NEXT_PUBLIC_SITE_URL` set → view-source any page: canonical/OG/JSON-LD show the real domain
- [ ] `https://<domain>/sitemap.xml` lists only real URLs on the real domain
- [ ] `https://<domain>/robots.txt` references the real sitemap URL
- [ ] `https://<domain>/feed.xml` resolves
- [ ] Upload → Generate → Download works on the deployed runtime
- [ ] Old `/#/...` links land on `/` and are rewritten to the clean path (client-side shim, `HashRedirect.tsx`)
