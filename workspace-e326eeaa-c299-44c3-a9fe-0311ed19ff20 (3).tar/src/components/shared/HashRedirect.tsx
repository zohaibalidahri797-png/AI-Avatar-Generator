'use client';

import { useEffect } from 'react';
import { useRouter as useNextRouter } from 'next/navigation';
import { normalizeHref } from '@/lib/router';

/**
 * Legacy-hash migration shim.
 *
 * Hash fragments are never sent to the server, so old links like
 * `/#/ai-avatar-generator` or `/#/gallery?fav=1` land on `/` with a hash.
 * This component rewrites them once per load to the real, crawlable path
 * (`/ai-avatar-generator/`, `/gallery/?fav=1`) without a history entry, so
 * back/forward behavior stays correct and no redirect loops are possible.
 */
export default function HashRedirect() {
  const router = useNextRouter();

  useEffect(() => {
    const raw = window.location.hash;
    if (!raw.startsWith('#/')) return;
    const target = raw.slice(1); // '#/gallery?fav=1' -> '/gallery?fav=1'
    router.replace(normalizeHref(target));
  }, [router]);

  return null;
}
