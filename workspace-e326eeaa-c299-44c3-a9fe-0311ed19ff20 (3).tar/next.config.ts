import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  // Canonical URLs carry a trailing slash (e.g. /ai-avatar-generator/) so the
  // sitemap, canonical tags and address bar all agree on one URL convention.
  trailingSlash: true,
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
};

export default nextConfig;
